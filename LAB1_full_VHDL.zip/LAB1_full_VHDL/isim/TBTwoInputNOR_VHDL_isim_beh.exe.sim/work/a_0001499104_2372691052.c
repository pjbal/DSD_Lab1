/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//homes.student.eecs.qmul.ac.uk/pjb30/Documents/DSD/LAB1/LAB1_full_VHDL/TBTwoInputNOR_VHDL.vhd";



static void work_a_0001499104_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;

LAB0:    t1 = (t0 + 2512U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(69, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 2320);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(72, ng0);
    t2 = (t0 + 5003);
    *((unsigned char *)t2) = (unsigned char)2;
    t4 = (t0 + 5004);
    *((unsigned char *)t4) = (unsigned char)3;
    t5 = (unsigned char)2;
    t6 = (unsigned char)3;

LAB8:    if (t5 <= t6)
        goto LAB9;

LAB11:    xsi_set_current_line(83, ng0);

LAB24:    *((char **)t1) = &&LAB25;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB9:    xsi_set_current_line(73, ng0);
    t7 = (t0 + 5005);
    *((unsigned char *)t7) = (unsigned char)2;
    t8 = (t0 + 5006);
    *((unsigned char *)t8) = (unsigned char)3;
    t9 = (unsigned char)2;
    t10 = (unsigned char)3;

LAB12:    if (t9 <= t10)
        goto LAB13;

LAB15:
LAB10:    t2 = (t0 + 5003);
    t5 = *((unsigned char *)t2);
    t4 = (t0 + 5004);
    t6 = *((unsigned char *)t4);
    if (t5 == t6)
        goto LAB11;

LAB21:    t9 = (t5 + (unsigned char)1);
    t5 = t9;
    t7 = (t0 + 5003);
    *((unsigned char *)t7) = t5;
    goto LAB8;

LAB13:    xsi_set_current_line(75, ng0);
    t11 = (t0 + 5005);
    t12 = (t0 + 2896);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = *((unsigned char *)t11);
    xsi_driver_first_trans_fast(t12);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 5003);
    t4 = (t0 + 2960);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t11 = (t8 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = *((unsigned char *)t2);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(78, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 2320);
    xsi_process_wait(t2, t3);

LAB18:    *((char **)t1) = &&LAB19;
    goto LAB1;

LAB14:    t2 = (t0 + 5005);
    t9 = *((unsigned char *)t2);
    t4 = (t0 + 5006);
    t10 = *((unsigned char *)t4);
    if (t9 == t10)
        goto LAB15;

LAB20:    t17 = (t9 + (unsigned char)1);
    t9 = t17;
    t7 = (t0 + 5005);
    *((unsigned char *)t7) = t9;
    goto LAB12;

LAB16:    goto LAB14;

LAB17:    goto LAB16;

LAB19:    goto LAB17;

LAB22:    goto LAB2;

LAB23:    goto LAB22;

LAB25:    goto LAB23;

}


extern void work_a_0001499104_2372691052_init()
{
	static char *pe[] = {(void *)work_a_0001499104_2372691052_p_0};
	xsi_register_didat("work_a_0001499104_2372691052", "isim/TBTwoInputNOR_VHDL_isim_beh.exe.sim/work/a_0001499104_2372691052.didat");
	xsi_register_executes(pe);
}
